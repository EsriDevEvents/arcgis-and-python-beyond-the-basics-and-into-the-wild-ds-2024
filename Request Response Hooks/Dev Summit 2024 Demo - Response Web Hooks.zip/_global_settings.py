# Use this module to persist global variables across the package

global request_count
global request_count_start
global request_peroid_start
global dynamic_threshold
global dynamic_threshold_peroid
global dynamic_threshold_retries
request_count = 0
request_count_start = None
request_peroid_start = None
dynamic_threshold = None
dynamic_threshold_peroid = None
dynamic_threshold_retries = 0
